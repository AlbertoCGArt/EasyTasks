const { chromium } = require('playwright');
const path = require('path');

// usage: node render.js file.html out.png W H [scale]
(async () => {
  const [file, out, W, H, scale] = process.argv.slice(2);
  const w = parseInt(W), h = parseInt(H), s = parseFloat(scale || '2');
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: s });
  await page.goto('file://' + path.resolve(file));
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(400);
  await page.screenshot({ path: out });
  await browser.close();
  console.log('rendered', out, `${w*s}x${h*s}`);
})();
