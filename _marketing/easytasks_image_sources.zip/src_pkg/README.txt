Easy Tasks — marketing image sources
====================================
Each PNG in ../ is rendered from the matching .html file here, via headless Chromium.

  npm install @fontsource/inter @fontsource/jetbrains-mono playwright
  # copy the latin woff2 files into assets/ (see assets/fonts.css for names)
  node render.js  gumroad_cover.html  out/gumroad_cover_2560x1440.png  1280 720 2
  node render.js  gumroad_thumb.html  out/gumroad_thumbnail_1200x1200.png 600 600 2
  node render.js  web_hero.html       out/web_hero_2400x1000.png       1200 500 2
  node render.js  web_features.html   out/web_features_2400x1380.png   1200 690 2
  node render.js  web_specs.html      out/web_specs_2400x1240.png      1200 620 2
  node render_alpha.js logo_lockup.html out/easytasks_logo_lockup_1476x408.png 492 136 3

Args are: <html> <output.png> <cssWidth> <cssHeight> <scaleFactor>

assets/fonts.css  — @font-face + the colour tokens (--accent is Blender orange #F5871F)
assets/kit.css    — shared components: grid backdrop, chips, kbd keys, N-panel mock, cards
assets/mark.svg   — the logo mark on its own

Font files are NOT included (SIL OFL, fetch from npm/Google Fonts as above).
